
# Dashboard de Controle Financeiro Pessoal

Projeto desenvolvido com Flask (Python), HTML, CSS e JavaScript para gestão simples de receitas e despesas.

## Tecnologias usadas

- Python 3
- Flask
- SQLite
- HTML5
- CSS3
- JavaScript
- Chart.js

## Como rodar o projeto

1. Clone o repositório:
   ```
   git clone https://github.com/seu-usuario/seu-repo.git
   ```

2. Acesse a pasta:
   ```
   cd finance_dashboard
   ```

3. Crie e ative um ambiente virtual (opcional):
   ```
   python -m venv venv
   source venv/bin/activate  (Linux/Mac)
   venv\Scripts\activate    (Windows)
   ```

4. Instale as dependências:
   ```
   pip install -r requirements.txt
   ```

5. Rode o app:
   ```
   python app.py
   ```

6. Acesse no navegador:
   ```
   http://127.0.0.1:5000/
   ```
