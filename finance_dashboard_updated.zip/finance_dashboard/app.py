
from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

# Inicializar o banco de dados
def init_db():
    conn = sqlite3.connect('data/database.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            description TEXT,
            amount REAL,
            date TEXT,
            type TEXT
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    conn = sqlite3.connect('data/database.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM transactions')
    transactions = cursor.fetchall()

    cursor.execute('SELECT SUM(amount) FROM transactions WHERE type="receita"')
    receita_total = cursor.fetchone()[0] or 0
    cursor.execute('SELECT SUM(amount) FROM transactions WHERE type="despesa"')
    despesa_total = cursor.fetchone()[0] or 0

    conn.close()
    return render_template('index.html', transactions=transactions, receita_total=receita_total, despesa_total=despesa_total)

@app.route('/add', methods=['POST'])
def add_transaction():
    description = request.form['description']
    amount = float(request.form['amount'])
    date = request.form['date']
    type_ = request.form['type']
    
    conn = sqlite3.connect('data/database.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO transactions (description, amount, date, type) VALUES (?, ?, ?, ?)',
                   (description, amount, date, type_))
    conn.commit()
    conn.close()
    
    return redirect(url_for('index'))

if __name__ == '__main__':
    os.makedirs('data', exist_ok=True)
    init_db()
    app.run(debug=True)
