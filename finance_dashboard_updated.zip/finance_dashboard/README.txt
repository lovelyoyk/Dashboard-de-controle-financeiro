
DASHBOARD DE CONTROLE FINANCEIRO PESSOAL

Projeto desenvolvido com Flask (Python), HTML, CSS e JavaScript para gestão simples de receitas e despesas.

TECNOLOGIAS USADAS:
- Python 3
- Flask
- SQLite
- HTML5
- CSS3
- JavaScript
- Chart.js

COMO RODAR O PROJETO:

1. Clone o repositório:
   git clone https://github.com/seu-usuario/seu-repo.git

2. Acesse a pasta do projeto:
   cd finance_dashboard

3. (Opcional) Crie e ative um ambiente virtual:
   Windows:
       python -m venv venv
       venv\Scripts\activate
   Linux/Mac:
       python3 -m venv venv
       source venv/bin/activate

4. Instale as dependências:
   pip install -r requirements.txt

5. Execute o projeto:
   python app.py

6. Abra o navegador e acesse:
   http://127.0.0.1:5000/

OBS: A pasta "data/" é criada automaticamente ao rodar o projeto.
